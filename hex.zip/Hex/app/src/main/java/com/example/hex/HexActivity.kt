package com.example.hex

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.ResolveInfo
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.ColorMatrix
import android.graphics.ColorMatrixColorFilter
import android.graphics.Paint
import android.graphics.Path
import android.graphics.Typeface
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.BatteryManager
import android.os.Bundle
import android.provider.Settings
import android.text.Editable
import android.text.TextWatcher
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.InputMethodManager
import android.widget.BaseAdapter
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ListView
import android.widget.TextClock
import android.widget.TextView

val GREEN: Int = Color.parseColor("#00FF41")
val DIM: Int = Color.parseColor("#0B8A2E")

class AppItem(val label: String, val pkg: String, val icon: Drawable, val intent: Intent)

class HexView(ctx: Context, private val sizePx: Int) : View(ctx) {
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        color = GREEN
        strokeWidth = 4f
    }

    override fun onMeasure(w: Int, h: Int) {
        setMeasuredDimension(sizePx, sizePx)
    }

    override fun onDraw(canvas: Canvas) {
        val cx = width / 2f
        val cy = height / 2f
        val r = width / 2f - 6f
        val path = Path()
        for (i in 0 until 6) {
            val a = Math.toRadians(60.0 * i - 30.0)
            val x = (cx + r * Math.cos(a)).toFloat()
            val y = (cy + r * Math.sin(a)).toFloat()
            if (i == 0) path.moveTo(x, y) else path.lineTo(x, y)
        }
        path.close()
        canvas.drawPath(path, paint)
    }
}

class HexActivity : Activity() {
    private val all = ArrayList<AppItem>()
    private val shown = ArrayList<AppItem>()
    private lateinit var root: FrameLayout
    private lateinit var home: LinearLayout
    private lateinit var drawer: LinearLayout
    private lateinit var search: EditText
    private lateinit var list: ListView
    private lateinit var battery: TextView
    private lateinit var adapter: BaseAdapter
    private var drawerOpen = false
    private var y0 = 0f

    private val greenFilter = ColorMatrixColorFilter(
        ColorMatrix(
            floatArrayOf(
                0f, 0f, 0f, 0f, 0f,
                0.45f, 0.9f, 0.2f, 0f, 0f,
                0f, 0f, 0f, 0f, 0f,
                0f, 0f, 0f, 1f, 0f
            )
        )
    )

    private fun Int.dp(): Int = (this * resources.displayMetrics.density).toInt()

    private fun box(): GradientDrawable = GradientDrawable().apply {
        setColor(Color.BLACK)
        setStroke(2.dp(), GREEN)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        root = FrameLayout(this)
        root.setBackgroundColor(Color.BLACK)
        buildHome()
        buildDrawer()
        val mp = FrameLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT
        )
        root.addView(home, mp)
        root.addView(drawer, mp)
        drawer.visibility = View.GONE
        setContentView(root)
    }

    private fun buildHome() {
        home = LinearLayout(this)
        home.orientation = LinearLayout.VERTICAL
        home.gravity = Gravity.CENTER
        home.setBackgroundColor(Color.BLACK)
        home.setPadding(32.dp(), 32.dp(), 32.dp(), 32.dp())

        home.addView(HexView(this, 72.dp()))
        home.addView(View(this), LinearLayout.LayoutParams(1, 24.dp()))

        val clock = TextClock(this)
        clock.format12Hour = "h:mm"
        clock.format24Hour = "HH:mm"
        clock.textSize = 64f
        clock.typeface = Typeface.MONOSPACE
        clock.setTextColor(GREEN)
        clock.gravity = Gravity.CENTER
        home.addView(clock)

        val date = TextClock(this)
        date.format12Hour = "EEEE, MMM d"
        date.format24Hour = "EEEE, MMM d"
        date.textSize = 16f
        date.typeface = Typeface.MONOSPACE
        date.setTextColor(DIM)
        date.gravity = Gravity.CENTER
        home.addView(date)

        battery = TextView(this)
        battery.typeface = Typeface.MONOSPACE
        battery.setTextColor(DIM)
        battery.textSize = 14f
        battery.gravity = Gravity.CENTER
        battery.setPadding(0, 8.dp(), 0, 0)
        home.addView(battery)

        home.addView(View(this), LinearLayout.LayoutParams(1, 48.dp()))

        val open = TextView(this)
        open.text = "[ apps ]"
        open.typeface = Typeface.MONOSPACE
        open.setTextColor(GREEN)
        open.textSize = 20f
        open.gravity = Gravity.CENTER
        open.background = box()
        open.setPadding(40.dp(), 14.dp(), 40.dp(), 14.dp())
        open.setOnClickListener { openDrawer() }
        home.addView(open)

        val hint = TextView(this)
        hint.text = "swipe up"
        hint.typeface = Typeface.MONOSPACE
        hint.setTextColor(DIM)
        hint.textSize = 12f
        hint.gravity = Gravity.CENTER
        hint.setPadding(0, 12.dp(), 0, 0)
        home.addView(hint)

        home.setOnTouchListener { _, e ->
            if (e.action == MotionEvent.ACTION_DOWN) y0 = e.rawY
            if (e.action == MotionEvent.ACTION_UP && y0 - e.rawY > 100.dp()) openDrawer()
            true
        }
    }

    private fun buildDrawer() {
        drawer = LinearLayout(this)
        drawer.orientation = LinearLayout.VERTICAL
        drawer.setBackgroundColor(Color.BLACK)
        drawer.setPadding(16.dp(), 24.dp(), 16.dp(), 8.dp())

        search = EditText(this)
        search.hint = "> search"
        search.setHintTextColor(DIM)
        search.setTextColor(GREEN)
        search.typeface = Typeface.MONOSPACE
        search.textSize = 18f
        search.background = box()
        search.setPadding(12.dp(), 12.dp(), 12.dp(), 12.dp())
        search.isSingleLine = true
        search.addTextChangedListener(object : TextWatcher {
            override fun afterTextChanged(s: Editable?) { filter(s?.toString() ?: "") }
            override fun beforeTextChanged(s: CharSequence?, st: Int, c: Int, a: Int) {}
            override fun onTextChanged(s: CharSequence?, st: Int, b: Int, c: Int) {}
        })
        search.setOnEditorActionListener { _, _, _ ->
            if (shown.isNotEmpty()) launch(shown[0])
            true
        }
        drawer.addView(search)
        drawer.addView(View(this), LinearLayout.LayoutParams(1, 12.dp()))

        list = ListView(this)
        list.setBackgroundColor(Color.BLACK)
        list.divider = ColorDrawable(DIM)
        list.dividerHeight = 1
        list.selector = ColorDrawable(0x3300FF41)
        adapter = object : BaseAdapter() {
            override fun getCount(): Int = shown.size
            override fun getItem(p: Int): Any = shown[p]
            override fun getItemId(p: Int): Long = p.toLong()
            override fun getView(p: Int, cv: View?, parent: ViewGroup?): View {
                val row = (cv as? LinearLayout) ?: newRow()
                val a = shown[p]
                (row.getChildAt(0) as ImageView).setImageDrawable(a.icon)
                (row.getChildAt(1) as TextView).text = a.label.lowercase()
                return row
            }
        }
        list.adapter = adapter
        list.setOnItemClickListener { _, _, pos, _ -> launch(shown[pos]) }
        list.setOnItemLongClickListener { _, _, pos, _ ->
            try {
                startActivity(
                    Intent(
                        Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                        Uri.parse("package:" + shown[pos].pkg)
                    )
                )
            } catch (e: Exception) { }
            true
        }
        drawer.addView(
            list,
            LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f)
        )
    }

    private fun newRow(): LinearLayout {
        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        row.gravity = Gravity.CENTER_VERTICAL
        row.setPadding(8.dp(), 10.dp(), 8.dp(), 10.dp())
        val iv = ImageView(this)
        iv.layoutParams = LinearLayout.LayoutParams(40.dp(), 40.dp())
        iv.setColorFilter(greenFilter)
        val tv = TextView(this)
        tv.typeface = Typeface.MONOSPACE
        tv.setTextColor(GREEN)
        tv.textSize = 18f
        tv.setPadding(16.dp(), 0, 0, 0)
        row.addView(iv)
        row.addView(tv)
        return row
    }

    private fun loadApps() {
        val pm = packageManager
        val q = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val res: List<ResolveInfo> = pm.queryIntentActivities(q, 0)
        all.clear()
        for (r in res) {
            val pkg = r.activityInfo.packageName
            if (pkg == packageName) continue
            val i = Intent(Intent.ACTION_MAIN)
                .addCategory(Intent.CATEGORY_LAUNCHER)
                .setClassName(pkg, r.activityInfo.name)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED)
            all.add(AppItem(r.loadLabel(pm).toString(), pkg, r.loadIcon(pm), i))
        }
        all.sortBy { it.label.lowercase() }
        filter(search.text.toString())
    }

    private fun filter(q: String) {
        shown.clear()
        for (a in all) if (q.isBlank() || a.label.contains(q.trim(), true)) shown.add(a)
        adapter.notifyDataSetChanged()
    }

    private fun launch(a: AppItem) {
        try { startActivity(a.intent) } catch (e: Exception) { }
        closeDrawer()
    }

    private fun openDrawer() {
        drawerOpen = true
        drawer.visibility = View.VISIBLE
    }

    private fun closeDrawer() {
        drawerOpen = false
        val imm = getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager
        imm.hideSoftInputFromWindow(search.windowToken, 0)
        search.setText("")
        drawer.visibility = View.GONE
    }

    private fun updateBattery() {
        val b = registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        val lvl = b?.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) ?: -1
        val scale = b?.getIntExtra(BatteryManager.EXTRA_SCALE, 100) ?: 100
        battery.text = if (lvl >= 0) "bat " + (lvl * 100 / scale) + "%" else ""
    }

    override fun onResume() {
        super.onResume()
        loadApps()
        updateBattery()
    }

    override fun onNewIntent(intent: Intent?) {
        super.onNewIntent(intent)
        if (drawerOpen) closeDrawer()
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        if (drawerOpen) closeDrawer()
    }
}
